#include "mythread.h"

#include <QVector>

QString myThread::result = "";

bool myThread::found = false;

void myThread::setResult(QString str){
    result = str;
}

QString myThread::getResult() const{
    return result;
}

void myThread::setFound(bool b){
    found = b;
}

bool myThread::getFound() const{
    return found;
}

unsigned int myThread::getNbComputed() const{
    return nbComputed;
}

void myThread::decNbComputed(){
    if(nbComputed != 0){
        nbComputed--;
    }
}

void myThread::hacking(unsigned int start, unsigned int end){

    unsigned int i;
    unsigned int computed = 0;

    /*
     * Mot de passe à tester courant
     */
    QString currentPasswordString;

    /*
     * Tableau contenant les index dans la chaine charset des caractères de
     * currentPasswordString
     */
    QVector<unsigned int> currentPasswordArray;

    /*
     * On initialise le premier mot de passe à tester courant en le remplissant
     * de nbChars fois du premier caractère de charset
     */
    currentPasswordString.fill(charset.at(0),nbChars);
    currentPasswordArray.fill(0,nbChars);


    /*
     * On initialise le premier mot de passe à tester dans la range du thread actuel
     */
    for (unsigned int j = 0 ; j < nbChars; j++){
        currentPasswordArray[j] = start % charset.length();
        start /= charset.length();
    }

    /*
     * On traduit les index présents dans currentPasswordArray en
     * caractères
     */
    for (unsigned int i=0;i < nbChars; i++)
        currentPasswordString[i]  = charset.at(currentPasswordArray.at(i));

    /*
     * Object QCryptographicHash servant à générer des md5
     */
    QCryptographicHash md5(QCryptographicHash::Md5);

    /*
     * Hash du mot de passe à tester courant
     */
    QString currentHash;

    /*
     * Nombre de caractères différents pouvant composer le mot de passe
     */
    unsigned int nbValidChars = charset.length();

    /*
     * Tant qu'on a pas tout essayé...
     */
    while (start < end || !PcoThread::thisThread()->stopRequested()) {
        /* On vide les données déjà ajoutées au générateur */
        md5.reset();
        /* On préfixe le mot de passe avec le sel */
        md5.addData(salt.toLatin1());
        md5.addData(currentPasswordString.toLatin1());
        /* On calcul le hash */
        currentHash = md5.result().toHex();

        /*
         * Si on a trouvé, on retourne le mot de passe courant (sans le sel)
         * et on met un boolean global à tout les thread à vrai pour pouvoir
         * les stopper.
         */
        if (currentHash == hash){
               setResult(currentPasswordString);
               setFound(true);
               PcoThread::thisThread()->requestStop();
        }

        /*
         * On récupère le mot de pass à tester suivant.
         *
         * L'opération se résume à incrémenter currentPasswordArray comme si
         * chaque élément de ce vecteur représentait un digit d'un nombre en
         * base nbValidChars.
         *
         * Le digit de poids faible étant en position 0
         */
        i = 0;
        while (i < (unsigned int)currentPasswordArray.size()) {
            currentPasswordArray[i]++;

            if (currentPasswordArray[i] >= nbValidChars) {
                currentPasswordArray[i] = 0;
                i++;
            } else
                break;
        }

        /*
         * On traduit les index présents dans currentPasswordArray en
         * caractères
         */
        for (i=0;i<nbChars;i++)
            currentPasswordString[i]  = charset.at(currentPasswordArray.at(i));

        start++;
        computed++;

        if(computed == 1000){
            nbComputed++;
            computed = 0;
        }

        //if we found the correct String we have to stop all the
        //threads
        if(getFound() == true){
            PcoThread::thisThread()->requestStop();
        }

        //To be sure that they heard the requestStop()
        if(PcoThread::thisThread()->stopRequested()){
            return;
        }

    }
}
    
    
    
      










