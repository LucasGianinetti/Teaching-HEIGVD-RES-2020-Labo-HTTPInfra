#include <QCryptographicHash>
#include <QVector>
#include "mythread.h"

#include <pcosynchro/pcothread.h>

#include "threadmanager.h"

/*
 * std::pow pour les long long unsigned int
 */
long long unsigned int intPow (
        long long unsigned int number,
        long long unsigned int index)
{
    long long unsigned int i;

    if (index == 0)
        return 1;

    long long unsigned int num = number;

    for (i = 1; i < index; i++)
        number *= num;

    return number;
}

ThreadManager::ThreadManager(QObject *parent) :
    QObject(parent)
{}


void ThreadManager::incrementPercentComputed(double percentComputed)
{
    emit sig_incrementPercentComputed(percentComputed);
}

/*
 * Les paramètres sont les suivants:
 *
 * - charset:   QString contenant tous les caractères possibles du mot de passe
 * - salt:      le sel à concaténer au début du mot de passe avant de le hasher
 * - hash:      le hash dont on doit retrouver la préimage
 * - nbChars:   le nombre de caractères du mot de passe à bruteforcer
 * - nbThreads: le nombre de threads à lancer
 *
 * Cette fonction doit retourner le mot de passe correspondant au hash, ou une
 * chaine vide si non trouvé.
 */
QString ThreadManager::startHacking(
        QString charset,
        QString salt,
        QString hash,
        unsigned int nbChars,
        unsigned int nbThreads
)
{
    /*
     * Calcul du nombre de hash à générer
     */
    long long unsigned int nbToCompute = intPow(charset.length(),nbChars);

    /*
     * Calcul des index pour les différents threads.
     */
    unsigned int nbToComputeByThread = nbToCompute / nbThreads;


    std::vector<myThread*> threadList;
    myThread* current_thread;

    //Each thread is given an number of hash to try. We give
    //them the range with start and end.
    int start, end;

    for(size_t i = 0; i < nbThreads; i++){
        start = nbToComputeByThread * i;
        end = start + nbToComputeByThread - 1;

        current_thread = new myThread(charset,salt,hash,nbChars,start,end);
        threadList.push_back(current_thread);
    }

    //used to complete the progress bar
    unsigned int j = 0;

    //How the progress bar is incremented, explained in the README.md
    while(!current_thread->getFound()){
        for(size_t i = 0; i < nbThreads; i++){
            while(threadList[i]->getNbComputed()){
                incrementPercentComputed((double)1000/nbToCompute);
                j++;
                threadList[i]->decNbComputed();
            }
        }
    }

    //When we are done, we will certainly not be at the end of the progress bar
    //because we calculate the percent of computed hash. And a thread could find
    //the result before doing all fo them. That's why at the end we fill the progress
    //bar till 100%
    for(;j <= nbToCompute; j++){
        incrementPercentComputed((double)1000/nbToCompute);
    }

    /* Attends la fin de chaque thread et libère la mémoire associée.
     * Durant l'attente, l'application est bloquée.
     */
    for (long unsigned int i=0; i<nbThreads; i++)
    {
        threadList[i]->pcoThread->join();
    }
    /* Vide la liste de pointeurs de threads */
    threadList.clear();

    /*
     * Si on arrive ici, cela signifie que tous les mot de passe possibles ont
     * été testés, et qu'aucun n'est la préimage de ce hash.
     */
    return current_thread->getResult();
}
