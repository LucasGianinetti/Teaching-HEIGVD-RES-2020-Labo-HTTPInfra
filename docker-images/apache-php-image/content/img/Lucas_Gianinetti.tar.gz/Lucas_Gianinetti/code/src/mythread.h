#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QString>
#include <QCryptographicHash>
#include <pcosynchro/pcothread.h>

class myThread{

private :
    static QString result;
    static bool found;
    QString charset;
    QString salt;
    QString hash;
    unsigned int nbChars;
    unsigned int nbComputed;
    
public :

    PcoThread* pcoThread;

    myThread(QString charset, QString salt, QString hash, unsigned int nbChars, unsigned int start, unsigned int end){
        this->charset = charset;
        this->salt = salt;
        this->hash = hash;
        this->nbChars = nbChars;
        this->nbComputed = 0;
        pcoThread = new PcoThread(&myThread::hacking,std::ref(*this),start,end);
    }

    QString getResult() const;
    bool getFound() const;
    unsigned int getNbComputed() const;
    void decNbComputed();
    void hacking(unsigned int start, unsigned int end);

private :
    void setResult(QString str);
    void setFound(bool b);

};


#endif // MYTHREAD_H
