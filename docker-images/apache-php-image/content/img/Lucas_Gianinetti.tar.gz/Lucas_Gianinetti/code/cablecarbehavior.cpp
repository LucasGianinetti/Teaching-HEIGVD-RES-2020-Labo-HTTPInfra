//    ___  _________    ___  ___  ___  ___  //
//   / _ \/ ___/ __ \  |_  |/ _ \|_  |/ _ \ //
//  / ___/ /__/ /_/ / / __// // / __// // / //
// /_/   \___/\____/ /____/\___/____/\___/  //
//                                          //
// Auteurs : Nicolas Hungerbühler, Lucas Gianinetti

#include "cablecarbehavior.h"

void CableCarBehavior::run()
{
    //Tant que la cabine est en service elle va faire un tour complet
    while(cableCar->isInService()){
        cableCar->loadSkiers();
        cableCar->goUp();
        cableCar->unloadSkiers();
        cableCar->goDown();
    }
}
