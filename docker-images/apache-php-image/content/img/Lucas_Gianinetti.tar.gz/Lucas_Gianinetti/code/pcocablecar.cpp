//    ___  _________    ___  ___  ___  ___  //
//   / _ \/ ___/ __ \  |_  |/ _ \|_  |/ _ \ //
//  / ___/ /__/ /_/ / / __// // / __// // / //
// /_/   \___/\____/ /____/\___/____/\___/  //
//                                          //
// Auteurs : Nicolas Hungerbühler, Lucas Gianinetti

#include "pcocablecar.h"
#include <pcosynchro/pcothread.h>

#include <QDebug>
#include <QRandomGenerator>
constexpr unsigned int MIN_SECONDS_DELAY = 1;
constexpr unsigned int MAX_SECONDS_DELAY = 5;
constexpr unsigned int SECOND_IN_MICROSECONDS = 1000000;


PcoCableCar::PcoCableCar(const unsigned int capacity) :
    capacity(capacity),
    nbSkiersFQ(0),
    nbSkiersSQ(0),
    nbSkiersToProcess(0),

    inService(true),
    isDown(true),

    mutexFirstQueue(1),
    mutexSecondQueue(1),
    mutexEnd(1),

    semFirstQueue(0),
    semSecondQueue(0),
    semWaitingForSkiers(0),
    semInsideCableCar(0)
{

}

PcoCableCar::~PcoCableCar()
{

}

/**
 * @brief Le skieur va attendre de pouvoir rentrer dans la cabine, dans deux queues différentes suivant le moment ou il arrive.
 * @param id du skieur qui exécute cette méthode
 */
void PcoCableCar::waitForCableCar(int id)
{
    //#####################SECONDQUEUE#####################
    mutexSecondQueue.acquire();
    if(isInService()){
        if(isDown){     //Les skieurs qui arrivent quand la cabine est en bas et en service vont dans la secondQueue.

            nbSkiersSQ++;
            mutexSecondQueue.release();
            
            qDebug() << "Skieur" << id << " entre dans la secondQueue";
            semSecondQueue.acquire();
            qDebug() << "Skieur" << id << " quitte la secondQueue";


        }else{
            mutexSecondQueue.release();
        }
    }else{
        mutexSecondQueue.release();
    }
    
    //#####################FIRSTQUEUE#####################
    mutexFirstQueue.acquire();
    if(isInService()){ //Les skieurs qui arrivent quand la cabine est en service et pas en bas, ainsi que les skieurs quittant la secondQueue, vont dans la firstQueue


        nbSkiersFQ++;
        mutexFirstQueue.release();
       
        qDebug() << "Skieur" << id << " entre dans la firstQueue";
        semFirstQueue.acquire(); 
        
    }else{
        mutexFirstQueue.release();
    }
}

/**
 * @brief Les skieurs attendent à l'intérieur de la cabine que celle-ci soit arrivée en haut.
 * @param id du skieur qui exécute cette méthode
 */
void PcoCableCar::waitInsideCableCar(int id)
{
    qDebug() << "Skieur" << id << " attend à l'intérieur de la cabine!";
    semInsideCableCar.acquire();
}

/**
 * @brief Les skieurs quittant la firstQueue rentrent dans la cabine
 * @param id du skieur qui exécute cette méthode
 */
void PcoCableCar::goIn(int id)
{
    //Indique à la cabine que le skieur est à l'intérieur.
    qDebug() << "Skieur" << id << " entre dans la cabine.";
    semWaitingForSkiers.release();
}

/**
 * @brief Les skieurs quittent la cabine une fois que celle-ci est arrivée en haut.
 * @param id du skieur exécutant cette méthode.
 */
void PcoCableCar::goOut(int id)
{
    //Indique à la cabine que le skieur en est sorti
    qDebug() << "Skieur" << id << " sors de la cabine.";
    semWaitingForSkiers.release();
}

/**
 * @brief Indique si la cabine est en service ou non.
 * @return Retourne true si la cabine est en service, false si elle ne l'est pas.
 */
bool PcoCableCar::isInService()
{
    return inService;
}

/**
 * @brief Met la cabine hors-service, les skieurs attendant dans les queues sont liberés.
 */
void PcoCableCar::endService()
{
    mutexEnd.acquire();

    mutexSecondQueue.acquire();
    mutexFirstQueue.acquire();
    inService = false;

    //Libère les skieurs coincés dans la secondQueue
    for(size_t i = 0; i < nbSkiersSQ;++i){
        semSecondQueue.release();
    }
    nbSkiersSQ = 0;
    mutexSecondQueue.release();

    //Libère les skieurs coincés dans la firstQueue
    for(size_t i = 0;i < nbSkiersFQ;++i){
        semFirstQueue.release();
    }
    nbSkiersFQ = 0;
    mutexFirstQueue.release();   

    mutexEnd.release(); //pas d'importance vu qu'il ne sera plus acquire() mais comme ca le mutex reprend son etat de base.
}

/**
 * @brief La cabine monte une fois que les skieurs souhaités soient monté à bord, les skieurs attendant dans secondQueue sont libérés.
 */
void PcoCableCar::goUp()
{
    //Attend que tous les skieurs souhaités soient montés à bord.
    for(size_t i = 0; i < nbSkiersToProcess; ++i){
        semWaitingForSkiers.acquire();
    }

    qDebug() << "Le télécabine monte";

    //La cabine n'est plus à en bas
    mutexSecondQueue.acquire();
    isDown = false;
    mutexSecondQueue.release();

    //Libère les skieurs coincés dans la secondQueue
    for(size_t i = 0; i < nbSkiersSQ; ++i){
        semSecondQueue.release();
    }
    nbSkiersSQ = 0;

    PcoThread::usleep((MIN_SECONDS_DELAY + QRandomGenerator::system()->bounded(MAX_SECONDS_DELAY + 1)) * SECOND_IN_MICROSECONDS);
    qDebug() << "Le télécabine est arrivé en haut: les skieurs peuvent sortir!";

    mutexEnd.release();
}

/**
 * @brief La cabine descend une fois que les skieurs à son bord soient descendu.
 */
void PcoCableCar::goDown()
{
    //Attend que tous les skieurs soient descendu.
    for(size_t i = 0; i < nbSkiersToProcess;++i){
        semWaitingForSkiers.acquire();
    }
    nbSkiersToProcess = 0; //on reinitialise la valeur pour le prochain tour.

    qDebug() << "Le télécabine descend";
    PcoThread::usleep((MIN_SECONDS_DELAY + QRandomGenerator::system()->bounded(MAX_SECONDS_DELAY + 1)) * SECOND_IN_MICROSECONDS);

    mutexSecondQueue.acquire();
    isDown = true;
    mutexSecondQueue.release();

    qDebug() << "Le télécabine est arrivé en bas.";
    if(isInService()){
        qDebug() << "Les skieurs peuvent entrer.";
    }
}

/**
 * @brief Libère le nombre de skieurs voulu de la firstQueue.
 */
void PcoCableCar::loadSkiers()
{
    mutexEnd.acquire();

    //On libère de la firstQueue le nombre de skieurs maximum possible
    for(size_t i = 0; (i < nbSkiersFQ) && (i < capacity);++i){
        semFirstQueue.release();
        nbSkiersToProcess++;
    }
    /* PCO : cette soustraction ci-dessous devrait être protégée avec un mutex car :
     * Si on imagine qu'il y a des skieurs dans la SQ et qu'ils sont libérés lors du goUp()
     * afin qu'ils puissent aller dans la FQ mais si ils reprennent pas leur exécution directement
     * et que la cabine fasse tout son trajet pour enfin arriver ici et qu'on fasse un load de nbSkiers
     * pour modifier cette valeur (soustraction) et qu'on est préempté et qu'on imagine que les threads
     * vont maintenant modifier nbSkiersFQ (un à un car eux ils ont l'exclusion mutuelle entre eux)
     * nbSkiersFQ va changer mais ce changement n'aura pas été vu car on a déjà chargé la valeur ici.
     * puis on va l'écraser avec la soustraction quand c'est à nouveau notre tour et les incréments des threads n'auront
     * pas été comptabilisé (comme le laboratoire avec plusieurs threads qui font compteur++ sur le même compteur)
     *
     * Ce cas est extrêmement rare car il faut que le thread cabine fasse tout jusqu'à revenir ici, charger
     * la valeur de nbSkiersFQ de la mémoire et être interrompu juste après ce chargement (ou après la soustraction)
     * et qu'ensuite qu'un thread skieur modifie cette valeur. Mais cela pourrait arriver.
     *
     * Solution -> utiliser le même mutex qui empêche plusieurs threads skieur de modifier nbSkierFQ en même temps
     * pour rendre cette soustraction mutuellement exclusive par rapport aux incréments des threads skieurs */
    nbSkiersFQ -= nbSkiersToProcess;   //Ajuste le nombre de skieurs dans firstQueue
}

/**
 * @brief Libère les skieurs attendant dans la cabine.
 */
void PcoCableCar::unloadSkiers()
{
    for(size_t i = 0; i < nbSkiersToProcess;++i){
        semInsideCableCar.release();
    }
}
