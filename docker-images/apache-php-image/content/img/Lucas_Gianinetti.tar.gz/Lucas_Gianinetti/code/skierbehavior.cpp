//    ___  _________    ___  ___  ___  ___  //
//   / _ \/ ___/ __ \  |_  |/ _ \|_  |/ _ \ //
//  / ___/ /__/ /_/ / / __// // / __// // / //
// /_/   \___/\____/ /____/\___/____/\___/  //
//                                          //
// Auteurs : Nicolas Hungerbühler, Lucas Gianinetti

#include "skierbehavior.h"

#include <QRandomGenerator>

constexpr unsigned int MIN_SECONDS_DELAY = 2;
constexpr unsigned int MAX_SECONDS_DELAY = 10;
constexpr unsigned int SECOND_IN_MICROSECONDS = 1000000;

int SkierBehavior::nextId = 1;

void SkierBehavior::run()
{

    //Tant que la cabine est service, le skieur va faire un tour complet
    while(cableCar->isInService()){

        cableCar->waitForCableCar(id);

        //Si la cabine n'est plus en service, le(s) skieur(s) qui n'est/ne sont plus bloqués dans les files d'attente s'arrêtent
        if(!cableCar->isInService()){
            break;
        }
        cableCar->goIn(id);

        cableCar->waitInsideCableCar(id);
        cableCar->goOut(id);

        this->goDownTheMountain();
    }




}

void SkierBehavior::goDownTheMountain()
{
    qDebug() << "Skieur" << id << "est en train de skier et descend de la montagne";
    PcoThread::usleep((MIN_SECONDS_DELAY + QRandomGenerator::system()->bounded(MAX_SECONDS_DELAY + 1)) * SECOND_IN_MICROSECONDS);
    qDebug() << "Skieur" << id << "est arrivé en bas de la montagne";
}
